# Bansuri — Virtual Flute (Web + Android)

## Features
- Responsive Hindi-first interface for mobile and desktop.
- Virtual flute: tap/hold the seven note holes to synthesize notes using Web Audio.
- Selectable starter melody library, with bhajan, song-style and calm/original demo tunes.
- Play, pause, restart and next controls.
- Save your own note sequences locally in the browser.
- PWA manifest and service worker for install/offline shell.
- Capacitor configuration to package the same app for Android.

## Run locally
Install Node.js 20+.

```bash
npm install
npm run dev
```
Open the local URL shown by Vite.

## Build the web app
```bash
npm run build
npm run preview
```
Deploy the `dist/` folder to any static host (Vercel, Netlify, etc.). Serve over HTTPS for PWA installation and service worker support.

## Build Android app
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
Use Android Studio to build and run the APK/AAB. For future web changes, run `npm run build` and `npx cap sync android` again.

## Add more melodies
Open `app.js` and add an object to the `melodies` array:

```js
{
  id: "m7",
  title: "Your melody name",
  category: "भजन", // or "गीत" / "शांत"
  tag: "पारंपरिक / मौलिक",
  duration: "1:00",
  notes: [0, 2, 4, 5, 4, 2, 0]
}
```

Note indexes: `0=सा, 1=रे, 2=ग, 3=म, 4=प, 5=ध, 6=नि`.

## Important audio & content notes
The current sound is a synthesized flute-like tone generated in the browser; it is a functional prototype, not a recording of a professional bansuri. The included tune sequences are short starter/demo arrangements and may not match the full traditional or recorded versions of the named devotional pieces. A full catalogue of commercial songs requires licensed arrangements/audio or user-provided MIDI/note data. Do not add copyrighted recordings or arrangements without permission.


## Build APK using GitHub Actions (no Android Studio needed on your PC)
This project includes `.github/workflows/build-apk.yml`.

1. Create a GitHub repository and upload the entire project folder (including the hidden `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and press **Run workflow** (or push to `main`).
4. Open the completed workflow run, scroll to **Artifacts**, and download `Bansuri-debug-apk`.
5. Extract the ZIP artifact; it contains `app-debug.apk`. Transfer it to Android and install it.

This creates a debug APK for testing. A Play Store release needs a separately signed release build.
